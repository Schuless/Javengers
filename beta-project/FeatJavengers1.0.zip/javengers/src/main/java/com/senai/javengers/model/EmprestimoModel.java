package com.senai.javengers.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.Date;
import lombok.Data;

@Entity
@Table(name = "Emprestimos")
@Data
public class EmprestimoModel {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;
    
    @ManyToOne()
    @Column(name = "colaborador")
    private ColaboradorModel colaboradorModel;
    
    @Column(name = "equipamento")
    private String equipamento;
    
    @Column(name = "data")
    private Date data;
    
    
    @Column(name = "devolucao")
    private Date devolucao;
    
      
    public EmprestimoModel() {
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }
    
    public ColaboradorModel getColaborador(){
        return colaboradorModel;
    }
    
    public void setColaborador(ColaboradorModel colaboradorModel){
        this.colaboradorModel = colaboradorModel;
    }

    public String getEquipamento() {
        return equipamento;
    }

    public void setEquipamento(String equipamento) {
        this.equipamento = equipamento;
    }
    
    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
    
    public Date getDevolucao() {
        return devolucao;
    }

    public void setDevolucao(Date devolucao) {
        this.devolucao = devolucao;
    }
}
