package com.senai.javengers.service;

import org.springframework.stereotype.Service;

@Service
public class EmprestimoService {
    
}
